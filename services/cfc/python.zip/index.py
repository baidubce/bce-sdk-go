def handler(event, context): 
    print(event)
    return "Hello World"
